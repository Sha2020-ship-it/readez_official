from __future__ import division, print_function
import sys
import os
import pandas as pd
import openai
from flask import Flask, request, render_template, session, flash, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, LoginManager, login_user, login_required, logout_user, current_user
import utils
import bcrypt
import re 
from datetime import datetime

# Define a flask app
app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))

app.config['SQLALCHEMY_DATABASE_URI'] =\
        'sqlite:///' + os.path.join(basedir, 'database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = open('data/dbkey.txt').read()
db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

age_ratings = pd.read_excel('data/AoA_ratings_Kuperman_et_al_BRM.xlsx')
age_ratings = age_ratings[['Word', 'Rating.Mean']]

class User(db.Model, UserMixin):
    username = db.Column(db.String(20), nullable=False, primary_key=True, unique=True)
    password = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(50), nullable=False, unique=True)


    def get_id(self):
        # Return the unique username as the identifier
        return self.username


class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), nullable=False)
    datetime = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)  # Add default value
    feedback_text = db.Column(db.String(200), nullable=False)
    story = db.Column(db.String(999999), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    threshold = db.Column(db.Integer, nullable=False)
    processed_text = db.Column(db.String(999999), nullable=False)

    def __init__(self, username, feedback_text, story, title, threshold, processed_text):
        self.username = username
        self.feedback_text = feedback_text
        self.story = story
        self.title = title
        self.threshold = threshold
        self.processed_text = processed_text

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)

@app.route('/', methods=['POST','GET'])
def index():
    return render_template('home.html', current_user=current_user)

@app.route('/login', methods=['POST', 'GET'])
def login():
    error_messages = {
        'username': None,
        'password': None,
        'general': None,
    }

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Query the database for the user
        user = User.query.filter_by(username=username).first()

        if user and bcrypt.checkpw(password.encode('utf-8'), user.password):
            # If the user exists and the password is correct, log them in
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('portal'))
        else:
            error_messages['general'] = 'Login failed. Please check your username and password.'

    return render_template('login.html', error_messages=error_messages, current_user=current_user)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('index'))


@app.route('/portal', methods=['POST', 'GET'])
@login_required
def portal():
    # Main page accessible only after login
    return render_template('index.html', processed_text='Output Here.', current_user=current_user)

@app.route('/signup', methods=['POST', 'GET'])
def signup():
            # Perform validation
    error_messages = {
        'username': None,
        'email': None,
        'password': None,
        }
    success = False
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']

        # Add length checks for username, password, and email
        if len(username) < 4:
            error_messages['username'] = 'Username must be at least 4 characters long.'
        elif len(password) < 8:
            error_messages['password'] = 'Password must be at least 8 characters long.'

        # Check if the password contains at least one uppercase letter, one special character, and one number
        if not re.search(r'[A-Z]', password) or not re.search(r'[!@#$%^&*(),.?":{}|<>]', password) or not re.search(r'\d', password):
            error_messages['password'] = 'Password must contain at least one uppercase letter, one special character, and one number.'

        # Check if the username is already taken
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            error_messages['username'] = 'Username is already taken. Please choose another.'

        # Check if the email is already in use
        existing_email = User.query.filter_by(email=email).first()
        if existing_email:
            error_messages['email'] = 'Email is already in use. Please use a different email address.'

        if len(set(error_messages.values())) == 1:
            # Hash the password before storing it
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

            # If there are no validation errors, add the user to the database with the hashed password
            new_user = User(username=username, password=hashed_password, email=email)
            db.session.add(new_user)
            db.session.commit()

            success = True
            
    return render_template('signup.html', error_messages=error_messages, success=success, current_user=current_user)

@app.route('/generate', methods=['POST','GET'])
def upload():
    print(request)
    print('Inside if: ', request)
    data = dict(request.form)
    processed_text = utils.replace_story(data['story'], int(data['age']))
    
    # Store processed_text in the session
    session['processed_text'] = processed_text
    
    return render_template('generate.html', processed_text=processed_text, story=data['story'], title=data['title'], threshold=data['age'], current_user=current_user)


@app.route('/feedback', methods=['POST'])
def feedback():
    feedback_text = request.form['feedback']
    story = request.form['story']
    title = request.form['title']
    threshold = request.form['threshold']

    # Retrieve processed_text from the session
    processed_text = session.get('processed_text', '')
    
    # Create a new Feedback object and add it to the database
    new_feedback = Feedback(username=current_user.username, feedback_text=feedback_text, story=story, title=title, threshold=threshold, processed_text=processed_text)
    db.session.add(new_feedback)
    db.session.commit()

    return render_template('feedback.html', feedback=feedback_text, story=story, title=title, threshold=threshold, current_user=current_user, processed_text=processed_text)

@app.route('/user', methods=['GET'])
@login_required
def user():
    # Query the database to get the feedback history for the current user
    feedback_history = Feedback.query.filter_by(username=current_user.username).all()
    return render_template('user.html', feedback_history=feedback_history, current_user=current_user)


# CLI arguments of custom config
if __name__ == '__main__':
    app.run()
