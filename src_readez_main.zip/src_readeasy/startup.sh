#!/bin/bash

# Install required packages
pip install -r requirements.txt

# Set Flask app environment variables
export FLASK_APP=app.py
export FLASK_ENV=production

# Start Flask app
flask run
