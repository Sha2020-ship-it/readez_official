# Test app
Python 3.9+

conda 22.10+

pip 23.1+

## Installation details:

Input your text, age, and title into the respective fields, and press the submit button. After 2 minutes, another webpage will be opened with the results. 

```
pip install -r requirements.txt
python app.py
```

![Untitled video - Made with Clipchamp (3)](https://user-images.githubusercontent.com/72983931/233778014-20171509-33eb-4da7-9104-2c3f8f4c6d9e.gif)
